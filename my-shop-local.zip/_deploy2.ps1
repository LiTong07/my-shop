$token = '9846a87863f758bf5d148fb08d600b1e'
$owner = 'God-dao'
$repo = 'my-shop'
$apiBase = 'https://gitee.com/api/v5'

$files = @('bg-main.webp', 'bg-shiro.webp', 'bg-star.webp')

foreach ($f in $files) {
  $filePath = Join-Path $PSScriptRoot $f
  if (-not (Test-Path $filePath)) {
    Write-Host "SKIP $f (not found)"
    continue
  }
  Write-Host "Uploading $f ..."
  $bytes = [System.IO.File]::ReadAllBytes($filePath)
  $b64 = [Convert]::ToBase64String($bytes)
  $contentBody = @{
    access_token = $token
    content = $b64
    message = "add $f"
  } | ConvertTo-Json
  try {
    $r2 = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$f" -Method Post -Body $contentBody -ContentType 'application/json'
    Write-Host "  OK: $f"
  } catch {
    $err = $_.Exception.Message
    if ($err -match 'already exists') {
      try {
        $curr = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$f?access_token=$token" -Method Get
        $sha = $curr.sha
        $updateBody = @{
          access_token = $token
          content = $b64
          sha = $sha
          message = "update $f"
        } | ConvertTo-Json
        $r3 = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$f" -Method Put -Body $updateBody -ContentType 'application/json'
        Write-Host "  UPDATED: $f"
      } catch {
        Write-Host "  UPDATE FAILED: $f - $($_.Exception.Message)"
      }
    } else {
      Write-Host "  FAILED: $f - $err"
    }
  }
}

# Enable Gitee Pages
Write-Host ""
Write-Host "Enabling Gitee Pages..."
try {
  $pagesBody = @{
    access_token = $token
  } | ConvertTo-Json
  $pr = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/pages/builds" -Method Post -Body $pagesBody -ContentType 'application/json'
  Write-Host "Pages enabled! URL: https://$owner.gitee.io/$repo"
} catch {
  Write-Host "Pages enable failed (may need manual enable): $($_.Exception.Message)"
  Write-Host "Go to: https://gitee.com/$owner/$repo/pages"
}
