@echo off
chcp 65001 >nul
title 外烟国烟汇 - 本地启动器
echo.
echo  正在启动网站...
echo.

REM 检查 Node.js
where node >nul 2>&1
if %errorlevel% neq 0 (
    echo  [错误] 未检测到 Node.js，正在安装...
    echo  请稍候...
    winget install OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements >nul 2>&1
    if %errorlevel% neq 0 (
        echo.
        echo  [提示] 自动安装失败，请手动安装 Node.js:
        echo  https://nodejs.org/
        pause
        exit /b 1
    )
)

REM 启动服务器
echo  启动本地服务器...
cd /d "%~dp0"
start "" http://localhost:8080/index.html
node -e "const http=require('http'),fs=require('fs');http.createServer((q,r)=>{const p=q.url.split('?')[0];const f=p==='/'?'index.html':p.slice(1);fs.readFile(f,(e,d)=>{if(e){r.writeHead(404);r.end('Not Found')}else{const t=f.endsWith('.html')?'text/html':f.endsWith('.css')?'text/css':f.endsWith('.js')?'application/javascript':f.endsWith('.webp')?'image/webp':'application/octet-stream';r.writeHead(200,{'Content-Type':t});r.end(d)}})}).listen(8080)"

echo.
echo  网站已启动！浏览器已自动打开。
echo  地址: http://localhost:8080/
echo.
echo  按 Ctrl+C 关闭服务器
pause >nul