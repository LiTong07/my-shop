$token = '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'
$owner = 'LiTong07'
$repo = 'my-shop'
$apiBase = 'https://api.github.com'
$headers = @{
  Authorization = "token $token"
  Accept = 'application/vnd.github.v3+json'
  'User-Agent' = 'QClaw-AutoDeploy'
}

Write-Host "=== 1. Create Repo ===" -ForegroundColor Cyan
$createRepo = @{
  name = $repo
  description = "wa yan guo yan hui"
  private = $false
  has_issues = $true
  has_wiki = $false
  auto_init = $false
} | ConvertTo-Json

try {
  $r = Invoke-RestMethod -Uri "$apiBase/user/repos" -Method Post -Headers $headers -Body $createRepo -ContentType 'application/json'
  Write-Host "OK: $($r.html_url)" -ForegroundColor Green
} catch {
  Write-Host "Repo status: $($_.Exception.Message)" -ForegroundColor Yellow
}

Start-Sleep 2

Write-Host ""
Write-Host "=== 2. Upload Files ===" -ForegroundColor Cyan

$files = @(
  @{name='index.html'; path='C:\Users\Administrator\.qclaw\workspace\my-shop\index.html'},
  @{name='admin.html'; path='C:\Users\Administrator\.qclaw\workspace\my-shop\admin.html'},
  @{name='bg-main.webp'; path='C:\Users\Administrator\.qclaw\workspace\my-shop\bg-main.webp'},
  @{name='bg-shiro.webp'; path='C:\Users\Administrator\.qclaw\workspace\my-shop\bg-shiro.webp'},
  @{name='bg-star.webp'; path='C:\Users\Administrator\.qclaw\workspace\my-shop\bg-star.webp'}
)

foreach ($f in $files) {
  if (-not (Test-Path $f.path)) {
    Write-Host "  SKIP $($f.name)" -ForegroundColor Gray
    continue
  }
  Write-Host "  $($f.name)..." -NoNewline

  $sha = $null
  try {
    $existing = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$($f.name)?access_token=$token" -Method Get -Headers $headers
    $sha = $existing.sha
  } catch {}

  $bytes = [System.IO.File]::ReadAllBytes($f.path)
  $b64 = [Convert]::ToBase64String($bytes)

  $body = @{
    message = "add $($f.name)"
    content = $b64
  }
  if ($sha) { $body.sha = $sha }

  try {
    $r2 = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$($f.name)" `
      -Method Put -Headers $headers -Body ($body | ConvertTo-Json) -ContentType 'application/json'
    Write-Host " OK" -ForegroundColor Green
  } catch {
    Write-Host " FAIL: $($_.Exception.Message.Substring(0, [Math]::Min(80, $_.Exception.Message.Length)))" -ForegroundColor Red
  }
  Start-Sleep 1
}

Start-Sleep 2

Write-Host ""
Write-Host "=== 3. Enable GitHub Pages ===" -ForegroundColor Cyan

foreach ($branch in @('main', 'master')) {
  $pagesBody = @{
    source = @{
      branch = $branch
      path = '/'
    }
  } | ConvertTo-Json

  try {
    $r3 = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/pages" `
      -Method Post -Headers $headers -Body $pagesBody -ContentType 'application/json'
    Write-Host "Pages enabled with branch: $branch" -ForegroundColor Green
    Write-Host "URL: https://$($owner).github.io/$($repo)" -ForegroundColor Cyan
    break
  } catch {
    $errDetail = $_.Exception.Message
    if ($errDetail -notmatch 'already') {
      Write-Host "Branch $branch failed: $($errDetail.Substring(0, [Math]::Min(60, $errDetail.Length)))" -ForegroundColor Yellow
    }
  }
}

Write-Host ""
Write-Host "=== DONE ===" -ForegroundColor Green
Write-Host "Repo: https://github.com/$($owner)/$($repo)" -ForegroundColor Cyan
Write-Host "Site: https://$($owner).github.io/$($repo)" -ForegroundColor Cyan
Write-Host ""
Write-Host "If Pages not enabled yet:" -ForegroundColor Yellow
Write-Host "1. Go to: https://github.com/$($owner)/$($repo)/settings/pages" -ForegroundColor Yellow
Write-Host "2. Select branch main or master, folder /" -ForegroundColor Yellow
Write-Host "3. Wait 2-5 minutes" -ForegroundColor Yellow
