$token = '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'
$url = 'https://api.github.com/repos/LiTong07/my-shop/pages'

$body = @{
    source = @{
        branch = 'main'
        path = '/'
    }
} | ConvertTo-Json -Depth 3

Invoke-RestMethod -Uri $url -Method Put -Headers @{
    'Authorization' = "token $token"
    'Accept' = 'application/vnd.github.v3+json'
    'Content-Type' = 'application/json'
} -Body ([Text.Encoding]::UTF8.GetBytes($body))

Write-Host "Pages updated!"
