$token = "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"
$headers = @{
    Authorization = "token $token"
    Accept = "application/vnd.github.v3+json"
}

# Check pages info
Write-Output "=== Pages Info ==="
$pages = Invoke-RestMethod -Uri "https://api.github.com/repos/LiTong07/my-shop/pages" -Headers $headers
Write-Output "Status: $($pages.status)"
Write-Output "URL: $($pages.html_url)"
Write-Output "Source: $($pages.source | ConvertTo-Json -Compress)"

# Check latest deployment
Write-Output ""
Write-Output "=== Latest Deployments ==="
$deploys = Invoke-RestMethod -Uri "https://api.github.com/repos/LiTong07/my-shop/pages/deployments?per_page=3" -Headers $headers
foreach ($d in $deploys) {
    Write-Output "ID: $($d.id) | Status: $($d.status) | Created: $($d.created_at)"
}
