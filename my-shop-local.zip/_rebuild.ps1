$token = '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'
$user = 'LiTong07'
$repo = 'my-shop'
$baseUrl = "https://api.github.com/repos/$user/$repo/contents"

$files = @(
    'index.html',
    'admin.html', 
    'bg-main.webp',
    'bg-shiro.webp',
    'bg-star.webp'
)

foreach ($file in $files) {
    $filePath = "C:\Users\Administrator\.qclaw\workspace\my-shop\$file"
    $content = [Convert]::ToBase64String([IO.File]::ReadAllBytes($filePath))
    $url = "$baseUrl/$file"
    
    # Check if file exists and get SHA
    $sha = $null
    try {
        $existing = Invoke-RestMethod -Uri $url -Headers @{'Authorization'="token $token"; 'Accept'='application/vnd.github.v3+json'} -Method Get -ErrorAction SilentlyContinue
        $sha = $existing.sha
    } catch {}
    
    $body = @{
        message = "Upload $file"
        content = $content
    }
    if ($sha) { $body.sha = $sha }
    
    $json = $body | ConvertTo-Json -Depth 3
    
    Invoke-RestMethod -Uri $url -Method Put -Headers @{'Authorization'="token $token"; 'Accept'='application/vnd.github.v3+json'; 'Content-Type'='application/json'} -Body ([Text.Encoding]::UTF8.GetBytes($json)) | Out-Null
    
    Write-Host "Uploaded: $file"
}

Write-Host "`nAll files uploaded!"
