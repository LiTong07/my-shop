$token = "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"
$headers = @{
    Authorization = "token $token"
    Accept = "application/vnd.github.v3+json"
}

# Try to create a Cloudflare Pages deployment via GitHub Actions
# First, let's try to use Netlify API directly

# Actually, let's try Vercel - it has a simple deploy API

# Check if we can reach Cloudflare
try {
    $r = Invoke-WebRequest -Uri "https://api.cloudflare.com/client/v4/user" -TimeoutSec 5 -UseBasicParsing
    Write-Output "Cloudflare reachable"
} catch {
    Write-Output "Cloudflare error: $($_.Exception.Message)"
}

# Check if we can reach Vercel
try {
    $r = Invoke-WebRequest -Uri "https://vercel.com" -TimeoutSec 5 -UseBasicParsing
    Write-Output "Vercel reachable: $($r.StatusCode)"
} catch {
    Write-Output "Vercel error: $($_.Exception.Message)"
}

# Check if we can reach Netlify
try {
    $r = Invoke-WebRequest -Uri "https://app.netlify.com" -TimeoutSec 5 -UseBasicParsing
    Write-Output "Netlify reachable: $($r.StatusCode)"
} catch {
    Write-Output "Netlify error: $($_.Exception.Message)"
}

# Check DNS resolution for github.io
try {
    $dns = [System.Net.Dns]::GetHostAddresses("litong07.github.io")
    Write-Output "GitHub.io DNS: $($dns.IPAddressToString -join ', ')"
} catch {
    Write-Output "GitHub.io DNS error: $($_.Exception.Message)"
}
