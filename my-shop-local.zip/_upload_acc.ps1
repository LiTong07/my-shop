$token = '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'
$user = 'LiTong07'
$repo = 'my-shop'
$file = 'C:\Users\Administrator\.qclaw\workspace\my-shop\admin.html'

$content = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes([IO.File]::ReadAllText($file)))
$url = "https://api.github.com/repos/$user/$repo/contents/$file"

# Get current SHA
$sha = (Invoke-RestMethod -Uri $url -Headers @{'Authorization'="token $token"; 'Accept'='application/vnd.github.v3+json'} -Method Get).sha

# Upload
$body = @{
    message = 'Add accounting feature to admin panel'
    content = $content
    sha = $sha
} | ConvertTo-Json -Depth 3

$result = Invoke-RestMethod -Uri $url -Method Put -Headers @{'Authorization'="token $token"; 'Accept'='application/vnd.github.v3+json'; 'Content-Type'='application/json'} -Body ([Text.Encoding]::UTF8.GetBytes($body))

Write-Host "Upload successful!"
Write-Host "Commit SHA:" $result.content.sha
