$token = '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'
$user = 'LiTong07'
$repo = 'my-shop'
$baseUrl = "https://api.github.com/repos/$user/$repo"

$headers = @{
    'Authorization' = "token $token"
    'Accept' = 'application/vnd.github.v3+json'
    'Content-Type' = 'application/json'
}

# Create .nojekyll blob (empty file)
$content = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes(''))
$body = @{content=$content; encoding='base64'} | ConvertTo-Json
$blob = Invoke-RestMethod -Uri "$baseUrl/git/blobs" -Method Post -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($body))

# Get current tree
$ref = Invoke-RestMethod -Uri "$baseUrl/git/refs/heads/main" -Headers $headers
$commit = Invoke-RestMethod -Uri "$baseUrl/git/commits/$($ref.object.sha)" -Headers $headers
$tree = Invoke-RestMethod -Uri "$baseUrl/git/trees/$($commit.tree.sha)" -Headers $headers

# Add .nojekyll to tree
$newTree = @($tree.tree) + @(@{path='.nojekyll'; sha=$blob.sha; mode='100644'; type='blob'})
$treeBody = @{tree=$newTree} | ConvertTo-Json -Depth 5
$newTreeObj = Invoke-RestMethod -Uri "$baseUrl/git/trees" -Method Post -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($treeBody))

# Create commit
$commitBody = @{
    message = 'Add .nojekyll'
    tree = $newTreeObj.sha
    parents = @($commit.sha)
} | ConvertTo-Json

$newCommit = Invoke-RestMethod -Uri "$baseUrl/git/commits" -Method Post -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($commitBody))

# Update ref
$refBody = @{sha=$newCommit.sha; force=$true} | ConvertTo-Json
Invoke-RestMethod -Uri "$baseUrl/git/refs/heads/main" -Method Patch -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($refBody)) | Out-Null

Write-Host "Added .nojekyll!"
