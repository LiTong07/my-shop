$token = '9846a87863f758bf5d148fb08d600b1e'
$owner = 'God-dao'
$repo = 'my-shop'
$apiBase = 'https://gitee.com/api/v5'

# 1. Create repo
Write-Host "Creating repo..."
$body = @{
  access_token = $token
  name = $repo
  description = '外烟国烟汇 - 微信直供'
  private = 'false'
  auto_init = 'true'
}
try {
  $r = Invoke-RestMethod -Uri "$apiBase/user/repos" -Method Post -Body $body -ContentType 'application/x-www-form-urlencoded'
  Write-Host "Repo created: $($r.full_name)"
} catch {
  Write-Host "Repo may already exist: $($_.Exception.Message)"
}

# 2. Upload files
$files = @(
  'index.html',
  'admin.html',
  'd2476bd6.webp',
  '63673d41.webp',
  'b51a7d9c.webp',
  '12a53101.webp',
  'a39c22fa.webp'
)

foreach ($f in $files) {
  $filePath = Join-Path $PSScriptRoot $f
  if (-not (Test-Path $filePath)) {
    Write-Host "SKIP $f (not found)"
    continue
  }
  Write-Host "Uploading $f ..."
  $bytes = [System.IO.File]::ReadAllBytes($filePath)
  $b64 = [Convert]::ToBase64String($bytes)
  $contentBody = @{
    access_token = $token
    content = $b64
    message = "add $f"
  } | ConvertTo-Json
  
  try {
    $r2 = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$f" -Method Post -Body $contentBody -ContentType 'application/json'
    Write-Host "  OK: $f"
  } catch {
    $err = $_.Exception.Message
    if ($err -match 'already exists') {
      Write-Host "  EXISTS: $f (will update)"
      # Get current SHA
      try {
        $curr = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$f?access_token=$token" -Method Get
        $sha = $curr.sha
        $updateBody = @{
          access_token = $token
          content = $b64
          sha = $sha
          message = "update $f"
        } | ConvertTo-Json
        $r3 = Invoke-RestMethod -Uri "$apiBase/repos/$owner/$repo/contents/$f" -Method Put -Body $updateBody -ContentType 'application/json'
        Write-Host "  UPDATED: $f"
      } catch {
        Write-Host "  UPDATE FAILED: $f - $($_.Exception.Message)"
      }
    } else {
      Write-Host "  FAILED: $f - $err"
    }
  }
}

Write-Host ""
Write-Host "Done! Enable Gitee Pages at:"
Write-Host "https://gitee.com/$owner/$repo/pages"
