# Deploy to surge.sh - no account needed, auto-registers
$email = "myshop2026@temp.com"
$password = "MyShop2026!"
$domain = "my-shop-2026.surge.sh"
$sitePath = "C:\Users\Administrator\.qclaw\workspace\my-shop"

# Create a project.json for surge
$projectJson = @"
{
  "name": "my-shop",
  "domain": "$domain"
}
"@
Set-Content -Path "$sitePath\CNAME" -Value $domain -NoNewline

Write-Output "Deploying to surge.sh..."
Write-Output "Domain: $domain"
