$token = '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'
$user = 'LiTong07'
$repo = 'my-shop'
$baseUrl = "https://api.github.com/repos/$user/$repo"

$headers = @{
    'Authorization' = "token $token"
    'Accept' = 'application/vnd.github.v3+json'
    'Content-Type' = 'application/json'
}

# Files to upload
$files = @(
    @{path='index.html'; file='C:\Users\Administrator\.qclaw\workspace\my-shop\index.html'},
    @{path='admin.html'; file='C:\Users\Administrator\.qclaw\workspace\my-shop\admin.html'},
    @{path='bg-main.webp'; file='C:\Users\Administrator\.qclaw\workspace\my-shop\bg-main.webp'},
    @{path='bg-shiro.webp'; file='C:\Users\Administrator\.qclaw\workspace\my-shop\bg-shiro.webp'},
    @{path='bg-star.webp'; file='C:\Users\Administrator\.qclaw\workspace\my-shop\bg-star.webp'}
)

# Create blobs
$blobs = @()
foreach ($f in $files) {
    $content = [Convert]::ToBase64String([IO.File]::ReadAllBytes($f.file))
    $body = @{content=$content; encoding='base64'} | ConvertTo-Json
    $blob = Invoke-RestMethod -Uri "$baseUrl/git/blobs" -Method Post -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($body))
    $blobs += @{path=$f.path; sha=$blob.sha; mode='100644'; type='blob'}
    Write-Host "Created blob: $($f.path)"
}

# Create tree
$treeBody = @{tree=$blobs} | ConvertTo-Json -Depth 5
$tree = Invoke-RestMethod -Uri "$baseUrl/git/trees" -Method Post -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($treeBody))
Write-Host "Created tree: $($tree.sha)"

# Create commit
$commitBody = @{
    message = 'Initial commit: cigarette shop website'
    tree = $tree.sha
} | ConvertTo-Json

$commit = Invoke-RestMethod -Uri "$baseUrl/git/commits" -Method Post -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($commitBody))
Write-Host "Created commit: $($commit.sha)"

# Update main branch ref
$refBody = @{
    sha = $commit.sha
    force = $true
} | ConvertTo-Json

$ref = Invoke-RestMethod -Uri "$baseUrl/git/refs/heads/main" -Method Patch -Headers $headers -Body ([Text.Encoding]::UTF8.GetBytes($refBody))
Write-Host "Updated main branch: $($ref.object.sha)"

Write-Host "`nDone! Website should be live soon."
